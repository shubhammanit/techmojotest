package toptweets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import Repository.HashTagRepository;
import services.TopTenTweetService;
// This is the main class which will run the entire application enter a tweet END to stop input. 

public class TopTweetsRunner {
	
	public static void main(String []args) throws IOException {
	     
		System.out.println("Enter the tweets, type END to stop");
		Pattern hashTagPattern = Pattern.compile("#(\\S+)");
		InputStreamReader reader = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(reader);
		String input = br.readLine();
		TopTenTweetService topTenTweetService = new TopTenTweetService();
		
		while(!input.equals("END")) {
		    Matcher match = hashTagPattern.matcher(input);
			while(match.find()) {
				String hashTag = match.group(1);
				HashTagRepository.save(hashTag);
			}
			input = br.readLine();
		}
		
		
		System.out.println(topTenTweetService.getTopTenHashTag(HashTagRepository.getAllHashTags()).toString());
		
	
	}

}
