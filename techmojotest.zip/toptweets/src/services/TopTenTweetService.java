package services;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.PriorityQueue;

import model.HashTag;
// A serive which return top 10 hashtags with help of priority queue with custom comparator
public class TopTenTweetService {
	
	class HashTagComparator implements Comparator<HashTag> {

		@Override
		public int compare(HashTag o1, HashTag o2) {
			// TODO Auto-generated method stub
			return o2.getCount() - o1.getCount();
		}	
	}
	
	public ArrayList<HashTag> getTopTenHashTag(HashSet<HashTag> hashTags){
		PriorityQueue<HashTag> topHashTags = new PriorityQueue<>(new HashTagComparator());
		topHashTags.addAll(hashTags);
		ArrayList<HashTag> ans = new ArrayList<>();
		int count = 0;
		while(count < 10 && !topHashTags.isEmpty()) {
			ans.add(topHashTags.poll());
			count = count + 1;
		}
		return ans;
	}
	
  

}
