package Repository;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;


import model.HashTag;

// This class keeps track of all the hashTag created and update their count as they found in new tweet
public class HashTagRepository {
	private static Map<String,HashTag> hashTags = new HashMap<>();
	
	public static void save(String hashTag) {
		if(hashTags.containsKey(hashTag)) {
			hashTags.get(hashTag).incrementCount();
		} else {
			hashTags.put(hashTag, new HashTag(hashTag));
		}
	}
   
	public static HashTag getHashTag(String hashTag) {
		return hashTags.get(hashTag);
	}
	
	public static HashSet<HashTag> getAllHashTags(){
		return new HashSet<>(hashTags.values());
	}
	
	
}
